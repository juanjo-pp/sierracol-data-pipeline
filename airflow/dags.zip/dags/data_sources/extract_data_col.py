import os
import io
import pandas as pd
from google.cloud import storage

GCS_BUCKET_NAME = "sierracol-data-storage"
GCS_FOLDER_PATH = "col/"  # Asegúrate de que termine con "/"
BQ_PROJECT_ID = "juanpe-sierracol"


def list_gcs_files(bucket_name, folder_path, prefix):
    """Lista los archivos en un bucket GCS dentro de una carpeta específica que inician con 'data_' y terminan en '.csv'."""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blobs = bucket.list_blobs(prefix=folder_path)  # Filtra por prefijo (carpeta)

    return [blob.name for blob in blobs if blob.name.startswith(f"{folder_path}{prefix}") and blob.name.endswith(".csv")]

def read_gcs_csv(bucket_name, file_path):
    """Lee un archivo CSV de GCS y lo convierte en un DataFrame de Pandas."""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(file_path)

    content = blob.download_as_bytes()  # Descarga el archivo como bytes
    return pd.read_csv(io.BytesIO(content))  # Carga en Pandas

def preparation_before_upload(name, df):

    new_name = name[4:-13]

    df["period_normal"] = new_name[-4:]

    df.columns = df.columns.str.lower().str.replace(r"[ /.ñ]", "_", regex=True)

    return new_name ,df

def process_gcs_to_bq(prefix):
    """Lee todos los CSV en una carpeta de GCS y los sube a BigQuery."""
    files = list_gcs_files(GCS_BUCKET_NAME, GCS_FOLDER_PATH, prefix)
    print(f"Archivos encontrados: {files}")

    list_df = []

    for file in files:
        print(f"Procesando {file}...")
        df = read_gcs_csv(GCS_BUCKET_NAME, file)

        name, df = preparation_before_upload(file, df)
        dicci = {}
        dicci[name] = df

        list_df.append(dicci)

    return list_df

